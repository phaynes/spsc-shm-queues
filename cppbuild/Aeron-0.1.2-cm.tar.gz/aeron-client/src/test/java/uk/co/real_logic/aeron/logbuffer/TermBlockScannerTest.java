/*
 * Copyright 2015 Real Logic Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package uk.co.real_logic.aeron.logbuffer;

import org.junit.Before;
import org.junit.Test;
import uk.co.real_logic.agrona.BitUtil;
import uk.co.real_logic.agrona.concurrent.UnsafeBuffer;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static uk.co.real_logic.aeron.logbuffer.FrameDescriptor.FRAME_ALIGNMENT;
import static uk.co.real_logic.aeron.logbuffer.FrameDescriptor.lengthOffset;

public class TermBlockScannerTest
{
    private final UnsafeBuffer termBuffer = mock(UnsafeBuffer.class);

    @Before
    public void before()
    {
        when(termBuffer.capacity()).thenReturn(LogBufferDescriptor.TERM_MIN_LENGTH);
    }

    @Test
    public void shouldScanEmptyBuffer()
    {
        final int offset = 0;
        final int limit = termBuffer.capacity();

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(offset));
    }

    @Test
    public void shouldReadFirstMessage()
    {
        final int offset = 0;
        final int limit = termBuffer.capacity();
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(alignedMessageLength));
    }

    @Test
    public void shouldReadBlockOfTwoMessages()
    {
        final int offset = 0;
        final int limit = termBuffer.capacity();
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);
        when(termBuffer.getIntVolatile(lengthOffset(alignedMessageLength))).thenReturn(messageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(alignedMessageLength * 2));
    }

    @Test
    public void shouldReadBlockOfThreeMessagesThatFillBuffer()
    {
        final int offset = 0;
        final int limit = termBuffer.capacity();
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);
        final int thirdMessageLength = limit - (alignedMessageLength * 2);

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);
        when(termBuffer.getIntVolatile(lengthOffset(alignedMessageLength))).thenReturn(messageLength);
        when(termBuffer.getIntVolatile(lengthOffset(alignedMessageLength * 2))).thenReturn(thirdMessageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(limit));
    }

    @Test
    public void shouldReadBlockOfTwoMessagesBecauseOfLimit()
    {
        final int offset = 0;
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);
        final int limit = (alignedMessageLength * 2) + 1;

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);
        when(termBuffer.getIntVolatile(lengthOffset(alignedMessageLength))).thenReturn(messageLength);
        when(termBuffer.getIntVolatile(lengthOffset(alignedMessageLength * 2))).thenReturn(messageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(alignedMessageLength * 2));
    }

    @Test
    public void shouldFailToReadFirstMessageBecauseOfLimit()
    {
        final int offset = 0;
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);
        final int limit = alignedMessageLength  - 1;

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(offset));
    }

    @Test
    public void shouldReadOneMessageOnLimit()
    {
        final int offset = 0;
        final int messageLength = 50;
        final int alignedMessageLength = BitUtil.align(messageLength, FRAME_ALIGNMENT);
        final int limit = alignedMessageLength;

        when(termBuffer.getIntVolatile(lengthOffset(offset))).thenReturn(messageLength);

        final int newOffset = TermBlockScanner.scan(termBuffer, offset, limit);

        assertThat(newOffset, is(alignedMessageLength));
    }
}